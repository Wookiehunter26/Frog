/**
 * Class FrogPlayer - A player for a game of Frog.
 * 
 * Acknowledgments: Fill this in . . .
 *
 * @author Michael Norton and ...
 * @version ...
 */
public class FrogPlayer {

    public static final int WINNER = 100; // number of points to win

    private int current; // Player's score for the current roll
    private int score; // Player's total score.
    private int turnScore; // Player's score for the current turn

    private FrogDice dice; // Player's dice
    private String name; // Player's name.

    /**
     * Set player's name, instantiate the dice, and initialize the player's
     * scores to 0.
     *
     * @param nameArg The name of the player
     */
    public FrogPlayer( String nameArg ) {

        name = nameArg;
        dice = new FrogDice();
        turnScore = 0;
        score = 0;
        current = 0;

    } // method FrogPlayer (constructor)

    /*
     * Displays the human's or computer's turn
     */
    public String takeTurn() {

        return "Roll = (" + dice.toString() + "), Roll Points = " + this.current
                        + ", Turn Points = " + this.turnScore
                        + " , Total Points = " + this.score;
    }

    /**
     * Return the value of the most recent roll of the dice.
     *
     * @return the most recent roll of the dice
     */
    public int getCurrent() {

        return this.current;

    } // method getCurrentScore

    /**
     * Return the dice object.
     *
     * @return the FrogDice
     */
    public FrogDice getDice() {

        return dice;

    } // method getDice

    /**
     * Return the total score for the user.
     *
     * @return the total score
     */
    public int getScore() {

        return this.score;

    } // method getTotalScore.

    /**
     * Set score
     * @param score
     */
    public void setScore( int score ) {

        this.score = score;
    }// method setScore

    /**
     * Return the score for the the current turn.
     *
     * @return the turn score
     */
    public int getTurnScore() {

        return this.turnScore;
    } // method getTurnScore

    /**
     * Set TurnScore
     * @param turnScore
     */
    public void setTurnScore( int turnScore ) {

        // this.turnScore = this.turnScore + this.current;
        this.turnScore = turnScore;
    }// method setTurnScore

    /**
     * Return true if the player has won, false otherwise.
     *
     * @return boolean
     */
    public boolean hasWon() {

        return this.score >= 100;

    } // method hasWon

    /**
     * Reset the turn score to 0. This method should be called at the beginning
     * (or end) of each turn.
     */
    public void resetTurnScore() {

        turnScore = 0;
    } // method resetTurnScore

    /**
     * Roll the dice once. Adjust the player's score as determined by the roll.
     * Return true if the player can roll again. Return false if the player
     * rolls a double one.
     *
     * @return false if the player rolls double 1s, true otherwise.
     */
    public boolean rollDice() {

        int temp = dice.roll();

        if ( dice.hasDoubles() ) {
            temp *= 2;
        }

        this.current = temp;
        this.turnScore += temp;
        this.score += temp;
        
        return !dice.hasDoubleOnes();
    } // method rollDice

    /*
     * resets all values on double ones.
     */
    public void resetAll() {

        current = 0;
        turnScore = 0;
        score = 0;

    }

    /**
     * Return the player's name.
     * 
     * @return the player's name
     */
    public String toString() {

        return name;

    } // method toString

} // class FrogPlayer
